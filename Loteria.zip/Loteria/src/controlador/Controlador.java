package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import clases.Boleto;
import modelo.Modelo;
import vista.Vista;

public class Controlador implements ActionListener{

	private Modelo modelo;
	private Vista vista;
	
	public Controlador (Modelo modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;
		vista.leerFichero();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		switch (e.getActionCommand()) {
		case "Comprobar":
			try {
				Boleto boletoInt = vista.obtenerBoleto();
				Boleto boletoPrem;
				
				for (int i=0; i<modelo.getBoletosPremiados().size(); i++) {
					boletoPrem = modelo.getBoletoPremiado(i);
					if (boletoInt.equals(boletoPrem)) {
						double cantFinal = boletoPrem.getCantidad()*((boletoInt.getParticipacion()/20)/10);
						vista.escribeResultado(boletoPrem.getPremio(), cantFinal);
						break;
					}
					else {
						vista.escribeError("BOLETO NO PREMIADO");
					}
				}
				
			}
			catch (Exception exc) {
				vista.escribeError("Formato incorrecto o sin completar.");
			}
			break;
		case "Restablecer":
			try {
				vista.reset();
			} catch (Exception exc) {
				vista.escribeError("ERROR");
			}
			break;
		default:
			break;
		}
		
	}

}
