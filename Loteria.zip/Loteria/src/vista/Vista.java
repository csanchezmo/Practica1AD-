package vista;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controlador.Controlador;
import clases.Boleto;
import modelo.Modelo;

import java.awt.Color;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Vista extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldNum;
	private JTextField textFieldCantidadJugada;
	private JTextField textFieldPremio;
	private JTextField textFieldCantidad;
	private JButton btnRestablecer;
	private JButton btnComprobar;
	private JLabel lblResultado;
	private JLabel lblCantidadJugada;
	private JLabel lblPremio;
	private JLabel lblNum;
	private JLabel lblCantidad;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Vista frame = new Vista();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Vista() {
		getContentPane().setBackground(new Color(255, 128, 0));
		inicializar();	
	}

	private void inicializar() {
		// Indicamos posicion inicial (x,y) y tamaño (x,y)
		setBounds(100, 100, 600, 420);
		// Indicamos que al cerrar la ventana se termina el programa
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);

		lblCantidadJugada = new JLabel("Introduzca cantidad jugada:");
		lblCantidadJugada.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblCantidadJugada.setBackground(new Color(0, 255, 255));
		lblCantidadJugada.setBounds(27, 63, 196, 23);
		getContentPane().add(lblCantidadJugada);

		lblResultado = new JLabel("INTRODUCE TU BOLETO");
		lblResultado.setForeground(new Color(0, 0, 0));
		lblResultado.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblResultado.setBackground(new Color(0, 0, 0));
		lblResultado.setBounds(121, 90, 320, 76);
		getContentPane().add(lblResultado);

		lblPremio = new JLabel("Premio:");
		lblPremio.setForeground(new Color(0, 0, 0));
		lblPremio.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblPremio.setBackground(new Color(0, 255, 64));
		lblPremio.setBounds(27, 188, 101, 38);
		getContentPane().add(lblPremio);

		lblNum = new JLabel("Introduzca número:");
		lblNum.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblNum.setBackground(Color.CYAN);
		lblNum.setBounds(27, 30, 196, 23);
		getContentPane().add(lblNum);

		lblCantidad = new JLabel("Cantidad:");
		lblCantidad.setForeground(Color.BLACK);
		lblCantidad.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblCantidad.setBackground(new Color(0, 255, 64));
		lblCantidad.setBounds(27, 236, 101, 38);
		getContentPane().add(lblCantidad);

		textFieldNum = new JTextField();
		textFieldNum.setBounds(215, 30, 226, 20);
		getContentPane().add(textFieldNum);
		textFieldNum.setColumns(10);

		textFieldCantidadJugada = new JTextField();
		textFieldCantidadJugada.setColumns(10);
		textFieldCantidadJugada.setBounds(215, 67, 226, 20);
		getContentPane().add(textFieldCantidadJugada);

		textFieldPremio = new JTextField();
		textFieldPremio.setColumns(10);
		textFieldPremio.setBounds(138, 200, 86, 20);
		getContentPane().add(textFieldPremio);

		textFieldCantidad = new JTextField();
		textFieldCantidad.setColumns(10);
		textFieldCantidad.setBounds(137, 248, 86, 20);
		getContentPane().add(textFieldCantidad);

		btnComprobar = new JButton("Comprobar");
		btnComprobar.setBounds(312, 310, 89, 23);
		getContentPane().add(btnComprobar);

		btnRestablecer = new JButton("Restablecer");
		btnRestablecer.setBounds(474, 310, 89, 23);
		getContentPane().add(btnRestablecer);

		// Impedimos que se pueda cambiar el tamaño de la ventana
		setResizable(false);
	}

	//Este metodo indica que los botones los va a controlar el controlador.
	public void setControlador(Controlador c) {
		btnComprobar.addActionListener(c);
		btnRestablecer.addActionListener(c);
	}

	public void reset() {
		textFieldNum.setText("");
		textFieldCantidadJugada.setText("");
		textFieldPremio.setText("");
		textFieldCantidad.setText("");
	}

	//Escribe el premio y la cantidad
	//Muestra el mensaje de boleto premiado
	public void escribeResultado(int premio, double cantidad) {
		lblResultado.setBackground(Color.WHITE);
		// Pongo el color de texto en rojo para indicar que el resultado es incorrecto
		lblResultado.setForeground(Color.GREEN);
		lblResultado.setOpaque(true);
		// Muestro el resultado
		lblResultado.setText("BOLETO GANADOR");
		textFieldPremio.setText(String.valueOf(premio));
		textFieldCantidad.setText(String.valueOf(cantidad));
	}

	//Muestra el mensaje de boleto no premiado
	public void escribeError(String error) {
		lblResultado.setBackground(Color.WHITE);
		// Pongo el color de texto en rojo para indicar que el resultado es incorrecto
		lblResultado.setForeground(Color.RED);
		lblResultado.setOpaque(true);
		// Muestro el error
		lblResultado.setText(error);
		textFieldPremio.setText("0");
		textFieldCantidad.setText("0");
	}

	//PReguntar como comprobar que todos los caracteres son numeros y no letras. En caso de
	//detectar una letra, lanzar excepcion.
	public Boleto obtenerBoleto() {
		//try {
		//for (int i = 0; i<textFieldNum.getText().length(); i++) {
		//if(textFieldNum.getText().charAt(i)) {

		//}
		//}
		int numeroIntroducido = Integer.valueOf(textFieldNum.getText());
		double cantidadIntroducida = Double.valueOf(textFieldCantidadJugada.getText());
		Boleto boletoIntroducido = new Boleto(numeroIntroducido, cantidadIntroducida);
		return boletoIntroducido;	
		//}
		//catch (IOException e) {
		//escribeError ("Error. Debe introducir carácteres numéricos.");
		//}

	}

	/**
	 * Se hace visible la ventana, arrancando la aplicacion de cara al usuario
	 */
	public void arrancar() {
		setVisible(true);
	}

	public void leerFichero() {
		String archivo = "lBoletosPremiados.txt";
		String linea;
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);

			while ((linea = br.readLine()) != null) {
				String[] datos = linea.split(";");
				Boleto b1 = new Boleto(Integer.valueOf(datos[0]), Integer.valueOf(datos[1]), Double.valueOf(datos[2]));
			}

			br.close();
		} catch (IOException e) {
			System.out.println("Error al leer el archivo.");
		}
	}
}