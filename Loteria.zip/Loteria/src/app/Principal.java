package app;

import vista.Vista;
import modelo.Modelo;
import controlador.Controlador; 

/**
 * Clase principal que genera la vista y el modelo, se los envía al controlador y arranca la vista
 * Tras arrancar la vista la ejecución de la aplicación se realiza respondiendo a eventos cuando el usuario
 * pulsa los diferentes botones
 */
public class Principal {

	public static void main(String args[]) {
		try {
			// Generamos la vista y el modelo
			Vista vista = new Vista();
			Modelo modelo = new Modelo();
			// Lanzamos el constructor del controlador
			Controlador controlador = new Controlador(modelo, vista);
			// Asignamos el controlador para que se encargue de manejar los eventos
			vista.setControlador(controlador);
			// Arrancamos la vista para que se muestre
			vista.arrancar();
		}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("Error al lanzar el programa");
		}
	}
}
