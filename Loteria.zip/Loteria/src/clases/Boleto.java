package clases;

import java.util.Objects;

public class Boleto {
	//Atributos del boleto.
	int numero;
	int serie;
	int premio;
	double cantidad;
	double participacion;
	
	//Constructor. Recibe el numero del boleto y la cantidad jugada.
	public Boleto(int numero, double participacion) {
		super();
		this.numero = numero;
		this.participacion = participacion;
	}
	
	public Boleto(int numero, int premio, double cantidad) {
		super();
		this.numero = numero;
		this.premio = premio;
		this.cantidad = cantidad;
	}

	//Getters y Setters
	public int getNumero() {
		return numero;
	}

	public int getSerie() {
		return serie;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public void setSerie(int serie) {
		this.serie = serie;
	}

	public int getPremio() {
		return premio;
	}

	public void setPremio(int premio) {
		this.premio = premio;
	}

	public double getCantidad() {
		return cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}

	public double getParticipacion() {
		return participacion;
	}

	public void setParticipacion(double participacion) {
		this.participacion = participacion;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Boleto other = (Boleto) obj;
		return numero == other.numero;
	}

	
	
	
	
}
