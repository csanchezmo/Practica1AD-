package modelo;
import java.util.ArrayList;
import clases.Boleto;

public class Modelo {
	
	private ArrayList<Boleto> boletosPremiados;
	private static int numBoletosPremiados = 0;
	
	public Modelo(){
		boletosPremiados = new ArrayList<Boleto>();
	}

	public ArrayList<Boleto> getBoletosPremiados() {
		return boletosPremiados;
	}
	
	public Boleto getBoletoPremiado(int i) {
		return boletosPremiados.get(i);
	}

	public void setBoletosPremiados(ArrayList<Boleto> boletosPremiados) {
		this.boletosPremiados = boletosPremiados;
	}

	public static int getNumBoletosPremiados() {
		return numBoletosPremiados;
	}

	public static void setNumBoletosPremiados(int numBoletosPremiados) {
		Modelo.numBoletosPremiados = numBoletosPremiados;
	}
	
}
